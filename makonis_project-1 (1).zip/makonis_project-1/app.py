from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
import sqlite3

# Initialize Flask app
app = Flask(__name__)
app.secret_key = "secret_key"  # For flashing messages

# Set up the database URI (SQLite)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy object (for database interaction)
db = SQLAlchemy(app)

# Define the User model (table schema)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    blood_donations = db.relationship('BloodDonation', backref='user', lazy=True)

# Define the BloodDonation model (table schema)
class BloodDonation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    age = db.Column(db.Integer, nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    blood_group = db.Column(db.String(10), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

# Admin credentials (you can replace these with database storage if needed)
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "adminpass"

# Routes for the app
@app.route('/')
def home():
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        new_user = User(name=name, email=email, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('signup.html')

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email, password=password).first()
        if user:
            session['user_id'] = user.id  # Store user ID in session
            # Check if the user has already registered for blood donation
            donation = BloodDonation.query.filter_by(user_id=user.id).first()
            if donation:
                # Existing user: Redirect to thank you page with all options
                return render_template('thank_you.html', user=user)
            else:
                # New user: Redirect to blood donation registration
                return redirect(url_for('blood_donation_registration', user_id=user.id))
        else:
            return "Invalid credentials! Please try again."
    return render_template('login.html')

@app.route('/register_blood_donation/<int:user_id>', methods=['GET', 'POST'])
def blood_donation_registration(user_id):
    if 'user_id' not in session or session['user_id'] != user_id:
        return redirect(url_for('signin'))  # Redirect to login if user is not logged in

    user = User.query.get_or_404(user_id)
    # Check if the user has already registered for blood donation
    donation = BloodDonation.query.filter_by(user_id=user.id).first()
    if donation:
        # Existing user: Redirect to view all registrations
        return redirect(url_for('view_all_registrations'))

    if request.method == 'POST':
        age = request.form['age']
        phone_number = request.form['phone_number']
        state = request.form['state']
        city = request.form['city']
        blood_group = request.form['blood_group']
        donation = BloodDonation(age=age, phone_number=phone_number, state=state, city=city, blood_group=blood_group, user_id=user.id)
        db.session.add(donation)
        db.session.commit()
        return render_template('thank_you.html', user=user)
    return render_template('blood_donation_registration.html', user=user)

# New route to view blood request status
@app.route('/view_blood_request_status/<int:user_id>')
def view_blood_request_status(user_id):
    user = User.query.get_or_404(user_id)
    conn = sqlite3.connect('requests.db')  # Connect to the correct database
    cursor = conn.cursor()
    cursor.execute("SELECT id, user_name, blood_group, units_requested, contact, status FROM blood_requests WHERE user_name = ?", (user.name,))
    requests = cursor.fetchall()
    conn.close()
    return render_template('blood_request_status.html', requests=requests, user=user)

# Admin login route
@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect(url_for('admin_view'))
        else:
            flash('Invalid admin credentials!')
    return render_template('admin_login.html')

# Admin view route
@app.route('/admin/view', methods=['GET', 'POST'])
def admin_view():
    users = BloodDonation.query.all()
    return render_template('admin_view.html', users=users)

# Fetch blood requests for admin
@app.route('/admin/blood_requests', methods=['GET'])
def admin_blood_requests():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, user_name, blood_group, units_requested, contact, status FROM blood_requests")
    requests = cursor.fetchall()
    conn.close()
    return render_template('admin_blood_requests.html', requests=requests)

# Delete registration route (for admin)
@app.route('/admin/delete/<int:donation_id>', methods=['POST'])
def delete_registration(donation_id):
    donation = BloodDonation.query.get_or_404(donation_id)
    db.session.delete(donation)
    db.session.commit()
    flash('Registration deleted successfully!')
    return redirect(url_for('admin_view'))

# Fetch blood inventory
@app.route('/blood_inventory')
def blood_inventory():
    conn = sqlite3.connect('requests.db')  # Connect to the correct database
    cursor = conn.cursor()
    cursor.execute("SELECT blood_group, units_available FROM blood_inventory")
    blood_data = cursor.fetchall()
    conn.close()
    return render_template('blood_inventory.html', blood_data=blood_data)

# Update blood units
@app.route('/update_blood_units', methods=['POST'])
def update_blood_units():
    blood_group = request.form['blood_group']
    units = int(request.form['units'])
    
    conn = sqlite3.connect('requests.db')  # Use the correct database
    cursor = conn.cursor()
    cursor.execute("SELECT units_available FROM blood_inventory WHERE blood_group = ?", (blood_group,))
    current_units = cursor.fetchone()
    
    if current_units:
        new_units = current_units[0] + units
        cursor.execute("UPDATE blood_inventory SET units_available = ? WHERE blood_group = ?", (new_units, blood_group))
        conn.commit()
        conn.close()
        return redirect('/blood_inventory')
    else:
        conn.close()
        return "Blood group not found!", 404

# Get database connection
def get_db_connection():
    conn = sqlite3.connect('requests.db')
    conn.row_factory = sqlite3.Row  # Enables dictionary-style access
    return conn

@app.route('/request_blood', methods=['POST'])
def request_blood():
    user_name = request.form.get('user_name')
    blood_group = request.form.get('blood_group')
    units_required = request.form.get('units_requested')
    contact_number = request.form.get('contact')

    print(f"Received data: {user_name}, {blood_group}, {units_required}, {contact_number}")  # Debug statement

    if not all([user_name, blood_group, units_required, contact_number]):
        return jsonify({'error': 'All fields are required!'}), 400

    try:
        conn = sqlite3.connect('requests.db')  # Ensure using correct database
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO blood_requests (user_name, blood_group, units_requested, contact, status)
            VALUES (?, ?, ?, ?, ?)
        """, (user_name, blood_group, units_required, contact_number, 'Pending'))  # Explicitly set status

        conn.commit()
        conn.close()

        return jsonify({'message': 'Blood request submitted successfully!'})
    
    except sqlite3.Error as e:
        print(f"Database error: {e}")  # Debug statement
        return jsonify({'error': f'Database error: {e}'}), 500

# Update request status route
@app.route('/update_request_status', methods=['POST'])
def update_request_status():
    request_id = request.form.get('request_id')
    status = request.form.get('status')

    if not request_id or not status:
        return jsonify({'error': 'Invalid request'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("UPDATE blood_requests SET status = ? WHERE id = ?", (status, request_id))
    conn.commit()
    conn.close()

    return redirect(url_for('admin_blood_requests'))

@app.route('/search_blood_donors', methods=['GET'])
def search_blood_donors():
    blood_group = request.args.get('blood_group')
    state = request.args.get('state')

    if not blood_group or not state:
        return jsonify({'error': 'Blood group and state are required!'}), 400

    try:
        # Query the blood_donation table and join with the user table to get donor details
        donors = db.session.query(BloodDonation, User).join(User, BloodDonation.user_id == User.id)\
            .filter(BloodDonation.blood_group == blood_group, BloodDonation.state == state)\
            .all()

        # Format the results
        results = []
        for donation, user in donors:
            results.append({
                'name': user.name,
                'age': donation.age,
                'phone_number': donation.phone_number,
                'state': donation.state,
                'city': donation.city,
                'blood_group': donation.blood_group
            })

        return jsonify(results)
    
    except Exception as e:
        return jsonify({'error': f'An error occurred: {str(e)}'}), 500

# View all registrations route
@app.route('/view_all_registrations')
def view_all_registrations():
    if 'user_id' not in session:
        return redirect(url_for('signin'))  # Redirect to login if user is not logged in

    current_user_id = session['user_id']  # Get the current user's ID from the session
    donors = db.session.query(BloodDonation, User).join(User, BloodDonation.user_id == User.id).all()
    return render_template('view_all_registration.html', donors=donors, current_user_id=current_user_id)

# Delete user's own registration route
@app.route('/delete_own_registration/<int:donation_id>', methods=['POST'])
def delete_own_registration(donation_id):
    if 'user_id' not in session:
        return redirect(url_for('signin'))  # Redirect to login if user is not logged in

    donation = BloodDonation.query.get_or_404(donation_id)
    if donation.user_id == session['user_id']:  # Ensure the user can only delete their own registration
        db.session.delete(donation)
        db.session.commit()
        flash('Your registration has been deleted successfully!', 'success')
    else:
        flash('You are not authorized to delete this registration!', 'error')
    return redirect(url_for('view_all_registrations'))

@app.route('/quiz')
def quiz():
    return render_template('quiz.html')
if __name__ == '__main__':
    app.run(debug=True)